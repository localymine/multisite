/**
 * @copyright   2010-2015, The Titon Project
 * @license     http://opensource.org/licenses/BSD-3-Clause
 * @link        http://titon.io
 */

define(function() {
    // Include an empty jQuery file so that we can setup local dependencies
    // It also allows the files to be included externally in other projects
});